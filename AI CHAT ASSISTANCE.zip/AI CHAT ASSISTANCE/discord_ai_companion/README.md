# Discord AI Chat Companion

Desktop helper (Windows) that fixes your English before you reply on Discord.
**You always copy and send messages yourself. Nothing is sent to Discord automatically.**

Current status: dark UI, paste/clipboard, six sentence-correction actions, message analysis with slang
explanations and 3 replies, and **Live Watch** (screenshot-based). Floating mode, global hotkeys, history and
packaging come in later stages.

## Install (Windows, PowerShell)

```powershell
cd discord_ai_companion
py -3.10 -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

If activation is blocked: `Set-ExecutionPolicy -Scope Process Bypass`, then activate again.
The app launches without any setup. AI buttons stay disabled until you add a provider.

## Configure the AI provider

Open **Settings** in the app, pick a provider, paste your key, click **Test connection**, then **Save**.

| Provider | Base URL | Example model | Key needed |
|---|---|---|---|
| OpenAI-compatible (OpenAI) | `https://api.openai.com/v1` | `gpt-4o-mini` | yes |
| OpenAI-compatible (Ollama, local) | `http://localhost:11434/v1` | `llama3.1` | no |
| OpenAI-compatible (LM Studio, local) | `http://localhost:1234/v1` | your loaded model | no |
| Anthropic | `https://api.anthropic.com` | `claude-haiku-5-5` | yes |

The key is read from, in this order: the `DISCORD_AI_API_KEY` environment variable,
the key saved from Settings (`%APPDATA%\DiscordAIChatCompanion\secrets.env`),
then a project `.env` file (copy `.env.example`). Keys are never hardcoded, shown in the UI, or logged.
Logs: `%APPDATA%\DiscordAIChatCompanion\logs\app.log`.

## Use it

1. Paste a received message on the left (optional in this stage).
2. Type your reply on the right, then click an action (Ctrl+Enter = Correct Grammar).
3. Click **Copy** on the result, paste into Discord, review, send.

## Tests

```powershell
pip install -r requirements-dev.txt
pytest
```

## Live Watch (see new messages and get replies)

1. Put Discord next to this window (the app must not cover the chat).
2. Click **Select chat area**, then drag over the Discord messages. Esc cancels.
3. Enter your Discord name (so your own messages are skipped), then click **Start live**.
4. When a new message from someone else appears, replies show up with Copy buttons. The taskbar icon flashes.
   Use **Pin on top** to keep the app visible. **Pause** and **Stop** work at any time; the title bar shows `LIVE`.

How it works: every N seconds it takes a screenshot of only the area you selected. If it changed and then
stayed still, that screenshot is sent to your AI provider (once per new message). Nothing is sent to Discord.
Live Watch needs a **vision-capable model** (e.g. `gpt-4o-mini`, `claude-haiku-5-5`, or `llama3.2-vision` / `llava` on Ollama).
It stops by itself after a bad key, rate limit, or 3 failures in a row.

## Auto-reply on copy (recommended, most accurate)

1. Tick **Auto-reply when I copy a message** and confirm the privacy prompt.
2. In Discord, select the message with your mouse and press **Ctrl+C**.
3. The text appears in the app and replies show up within a second or two. Click **Copy** on one, paste, send.

Only text you copy while the box is ticked is sent to your AI provider. It works with any text model (no vision needed).
Copying a reply with the app's own Copy button is ignored. Untick the box to stop.
