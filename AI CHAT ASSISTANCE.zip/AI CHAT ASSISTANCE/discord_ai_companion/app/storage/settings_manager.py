"""Non-secret settings (JSON) and API-key storage (kept out of settings and logs)."""
from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass, fields
from pathlib import Path

from app.utils.validators import is_local_url

log = logging.getLogger(__name__)

APP_DIR_NAME = "DiscordAIChatCompanion"
ENV_KEY_NAME = "DISCORD_AI_API_KEY"

PROVIDER_OPENAI = "openai_compatible"
PROVIDER_ANTHROPIC = "anthropic"
PROVIDER_DEFAULTS: dict[str, tuple[str, str]] = {
    PROVIDER_OPENAI: ("https://api.openai.com/v1", "gpt-4o-mini"),
    PROVIDER_ANTHROPIC: ("https://api.anthropic.com", "claude-haiku-5-5"),
}


def data_dir() -> Path:
    base = os.environ.get("APPDATA")
    root = Path(base) if base else Path.home() / ".config"
    path = root / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


@dataclass
class Settings:
    provider: str = PROVIDER_OPENAI
    base_url: str = PROVIDER_DEFAULTS[PROVIDER_OPENAI][0]
    model: str = PROVIDER_DEFAULTS[PROVIDER_OPENAI][1]
    temperature: float = 0.6
    timeout_s: int = 30
    always_on_top: bool = False
    my_name: str = ""
    live_interval_s: int = 3


class SettingsManager:
    def __init__(self, path: Path) -> None:
        self._path = path
        self.settings = self._load()

    def _load(self) -> Settings:
        if not self._path.exists():
            return Settings()
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            known = {f.name for f in fields(Settings)}
            return Settings(**{k: v for k, v in raw.items() if k in known})
        except (OSError, ValueError, TypeError):
            log.warning("Settings file unreadable; using defaults.")
            return Settings()

    def save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(asdict(self.settings), indent=2), encoding="utf-8")


def parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return values
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def load_dotenv(path: Path) -> None:
    """Load KEY=VALUE pairs into os.environ without overriding existing variables."""
    for key, value in parse_env_file(path).items():
        os.environ.setdefault(key, value)


class SecretStore:
    """Stores the API key in a local file that is excluded from version control."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def get_api_key(self) -> str | None:
        return os.environ.get(ENV_KEY_NAME) or None

    def set_api_key(self, key: str) -> None:
        key = key.strip()
        if not key or "\n" in key or "\r" in key:
            raise ValueError("That doesn't look like a valid API key.")
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(f"{ENV_KEY_NAME}={key}\n", encoding="utf-8")
        try:
            os.chmod(self._path, 0o600)
        except OSError:
            pass
        os.environ[ENV_KEY_NAME] = key

    def clear_api_key(self) -> None:
        try:
            self._path.unlink(missing_ok=True)
        except OSError:
            log.warning("Could not delete the saved key file.")
        os.environ.pop(ENV_KEY_NAME, None)


def provider_needs_no_key(settings: Settings) -> bool:
    return settings.provider == PROVIDER_OPENAI and is_local_url(settings.base_url)


def provider_host(settings: Settings) -> str:
    from urllib.parse import urlparse

    if settings.provider == PROVIDER_ANTHROPIC:
        return "api.anthropic.com"
    return urlparse(settings.base_url).hostname or "your AI provider"
