"""Input validation helpers."""
from __future__ import annotations

from urllib.parse import urlparse

MAX_SENTENCE_CHARS = 2000


class ValidationError(ValueError):
    """Raised when user input is not acceptable. The message is user-friendly."""


def validate_sentence(text: str) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        raise ValidationError("Type or paste a sentence first.")
    if len(cleaned) > MAX_SENTENCE_CHARS:
        raise ValidationError(
            f"That's too long ({len(cleaned)} characters). Keep it under {MAX_SENTENCE_CHARS}."
        )
    return cleaned


def validate_base_url(url: str) -> str:
    cleaned = (url or "").strip().rstrip("/")
    parsed = urlparse(cleaned)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValidationError("Base URL must start with http:// or https://")
    return cleaned


def is_local_url(url: str) -> bool:
    host = (urlparse(url or "").hostname or "").lower()
    return host in {"localhost", "127.0.0.1", "::1"}
