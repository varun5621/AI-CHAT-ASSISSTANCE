"""Clipboard read/write with a Qt fallback when pyperclip fails."""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class ClipboardError(RuntimeError):
    """Raised when the clipboard cannot be read or written."""


def _qt_clipboard():
    from PySide6.QtWidgets import QApplication

    app = QApplication.instance()
    if app is None:
        raise ClipboardError("Clipboard is not available yet.")
    return app.clipboard()


def read_clipboard_text() -> str:
    try:
        import pyperclip

        return (pyperclip.paste() or "").strip()
    except Exception:  # pyperclip raises several exception types
        log.info("pyperclip read failed; trying Qt clipboard.")
    try:
        return (_qt_clipboard().text() or "").strip()
    except Exception as exc:
        raise ClipboardError("Couldn't read the clipboard. Paste the text with Ctrl+V instead.") from exc


def copy_text(text: str) -> None:
    try:
        import pyperclip

        pyperclip.copy(text)
        return
    except Exception:
        log.info("pyperclip write failed; trying Qt clipboard.")
    try:
        _qt_clipboard().setText(text)
    except Exception as exc:
        raise ClipboardError("Couldn't copy to the clipboard. Select the text and press Ctrl+C.") from exc
