"""Screen-region picking and grabbing. Only the area the user selects is ever captured."""
from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QPoint, QRect, Qt, Signal
from PySide6.QtGui import QColor, QGuiApplication, QImage, QPainter, QPen
from PySide6.QtWidgets import QWidget

_QUANTIZE = bytes(b >> 5 for b in range(256))


@dataclass(frozen=True)
class Region:
    x: int
    y: int
    width: int
    height: int

    def describe(self) -> str:
        return f"{self.width}x{self.height}"


def grab_region(region: Region) -> QImage:
    center = QPoint(region.x + region.width // 2, region.y + region.height // 2)
    screen = QGuiApplication.screenAt(center) or QGuiApplication.primaryScreen()
    geo = screen.geometry()
    return screen.grabWindow(0, region.x - geo.x(), region.y - geo.y(), region.width, region.height).toImage()


def encode_jpeg(image: QImage, max_width: int = 1600) -> bytes:
    if image.width() > max_width:
        image = image.scaledToWidth(max_width, Qt.SmoothTransformation)
    data = QByteArray()
    buffer = QBuffer(data)
    buffer.open(QIODevice.WriteOnly)
    image.save(buffer, "JPEG", 85)
    return bytes(data.data())


def signature(image: QImage) -> bytes:
    """Coarse fingerprint so tiny changes (cursor blink, anti-aliasing) don't count as new messages."""
    small = image.scaledToWidth(160, Qt.SmoothTransformation).convertToFormat(QImage.Format_Grayscale8)
    return bytes(small.constBits()).translate(_QUANTIZE)


class RegionSelector(QWidget):
    """Full-screen overlay on a frozen screenshot; drag to choose the chat area. Esc cancels."""

    selected = Signal(object)
    cancelled = Signal()

    def __init__(self, screen) -> None:
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self._screen_origin = screen.geometry().topLeft()
        self._shot = screen.grabWindow(0)
        self._origin: QPoint | None = None
        self._current: QPoint | None = None
        self.setGeometry(screen.geometry())
        self.setCursor(Qt.CrossCursor)

    def _rect(self) -> QRect:
        return QRect(self._origin, self._current).normalized()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.drawPixmap(self.rect(), self._shot)
        painter.fillRect(self.rect(), QColor(0, 0, 0, 120))
        if self._origin is not None and self._current is not None:
            rect = self._rect()
            ratio = self._shot.width() / max(1, self.width())
            source = QRect(int(rect.x() * ratio), int(rect.y() * ratio), int(rect.width() * ratio), int(rect.height() * ratio))
            painter.drawPixmap(rect, self._shot, source)
            painter.setPen(QPen(QColor("#8b7cf6"), 2))
            painter.drawRect(rect)
        painter.setPen(QColor("white"))
        painter.drawText(24, 36, "Drag over the Discord chat messages. Press Esc to cancel.")

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self._origin = self._current = event.position().toPoint()
            self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._origin is not None:
            self._current = event.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, event) -> None:
        if self._origin is None:
            return
        rect = self._rect()
        if rect.width() < 60 or rect.height() < 40:
            self.cancelled.emit()
            return
        top_left = rect.topLeft() + self._screen_origin
        self.selected.emit(Region(top_left.x(), top_left.y(), rect.width(), rect.height()))

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Escape:
            self.cancelled.emit()
