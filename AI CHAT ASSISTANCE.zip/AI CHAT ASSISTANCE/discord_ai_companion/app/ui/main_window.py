"""Main dashboard window."""
from __future__ import annotations

import sys
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QMessageBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from app import APP_NAME
from app.capture.clipboard_capture import ClipboardError, copy_text
from app.services.ai_service import AIService
from app.services.clipboard_watcher import ClipboardWatcher
from app.services.grammar_corrector import GrammarCorrector
from app.services.message_analyzer import Analysis, MessageAnalyzer
from app.storage.settings_manager import SecretStore, SettingsManager, provider_host
from app.ui.correction_panel import CorrectionPanel
from app.ui.live_panel import LivePanel
from app.ui.message_panel import MessagePanel
from app.ui.reply_panel import ReplyPanel
from app.ui.settings_window import SettingsDialog
from app.ui.toast import Toast


def _enable_dark_title_bar(window: QWidget) -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes

        hwnd = int(window.winId())
        value = ctypes.c_int(1)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(value), ctypes.sizeof(value))
    except Exception:
        pass  # cosmetic only


class MainWindow(QMainWindow):
    def __init__(
        self,
        manager: SettingsManager,
        secrets: SecretStore,
        ai: AIService,
        corrector: GrammarCorrector,
    ) -> None:
        super().__init__()
        self._manager = manager
        self._secrets = secrets
        self._ai = ai
        self._title_bar_done = False
        self._auto_consented = False
        self.clip_watcher = ClipboardWatcher()

        self.setWindowTitle(APP_NAME)
        self.resize(1120, 800)
        self.setMinimumSize(900, 620)
        if manager.settings.always_on_top:
            self.setWindowFlag(Qt.WindowStaysOnTopHint, True)

        central = QWidget()
        central.setObjectName("root")
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        root.addLayout(self._build_header())
        root.addWidget(self._build_banner())

        self.analyzer = MessageAnalyzer(ai)
        self.message_panel = MessagePanel()
        self.reply_panel = ReplyPanel(self.analyzer)
        self.live_panel = LivePanel(manager, self.analyzer, self.reply_panel.tone)
        self.correction_panel = CorrectionPanel(corrector)

        left = QWidget()
        left.setObjectName("root")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 6, 0)
        left_layout.setSpacing(12)
        left_layout.addWidget(self.message_panel)
        left_layout.addWidget(self.live_panel)
        left_layout.addWidget(self.reply_panel, 1)
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(left)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(left_scroll)
        splitter.addWidget(self.correction_panel)
        splitter.setSizes([560, 520])
        root.addWidget(splitter, 1)

        self.privacy_label = QLabel()
        self.privacy_label.setObjectName("muted")
        self.privacy_label.setWordWrap(True)
        root.addWidget(self.privacy_label)

        self.toast = Toast(central)
        for panel in (self.message_panel, self.correction_panel, self.reply_panel, self.live_panel):
            panel.notify.connect(self._notify)
        self.reply_panel.copyRequested.connect(self._copy)
        self.message_panel.analyzeRequested.connect(
            lambda text: self.reply_panel.analyze_text(text, self._manager.settings.my_name)
        )
        self.message_panel.autoReplyToggled.connect(self._on_auto_toggled)
        self.clip_watcher.textCopied.connect(self._on_message_copied)
        self.live_panel.analysisReady.connect(self._on_live_analysis)
        self.live_panel.statusChanged.connect(self.reply_panel.set_status)
        self.live_panel.liveChanged.connect(self._on_live_changed)
        self.correction_panel.copyRequested.connect(self._copy)
        self._refresh_state()

    # ---- building ----------------------------------------------------------
    def _build_header(self) -> QHBoxLayout:
        titles = QVBoxLayout()
        title = QLabel(APP_NAME)
        title.setObjectName("title")
        subtitle = QLabel("Understand the chat. Say it naturally. You always press send.")
        subtitle.setObjectName("subtitle")
        titles.addWidget(title)
        titles.addWidget(subtitle)

        self.pin_btn = QPushButton("Pin on top")
        self.pin_btn.setCheckable(True)
        self.pin_btn.setChecked(self._manager.settings.always_on_top)
        self.pin_btn.toggled.connect(self._toggle_pin)
        settings_btn = QPushButton("Settings")
        settings_btn.clicked.connect(self._open_settings)

        row = QHBoxLayout()
        row.addLayout(titles)
        row.addStretch(1)
        row.addWidget(self.pin_btn)
        row.addWidget(settings_btn)
        return row

    def _build_banner(self) -> QFrame:
        self.banner = QFrame()
        self.banner.setObjectName("banner")
        layout = QHBoxLayout(self.banner)
        layout.setContentsMargins(16, 10, 16, 10)
        text = QLabel(
            "AI isn't set up yet. You can still paste messages and copy text. "
            "Add an API key (or a local model) to enable corrections."
        )
        text.setWordWrap(True)
        button = QPushButton("Open Settings")
        button.setProperty("variant", "primary")
        button.clicked.connect(self._open_settings)
        layout.addWidget(text, 1)
        layout.addWidget(button)
        return self.banner

    # ---- behavior ----------------------------------------------------------
    def _refresh_state(self) -> None:
        configured = self._ai.is_configured()
        self.banner.setVisible(not configured)
        self.correction_panel.set_ai_enabled(configured)
        self.message_panel.set_ai_enabled(configured)
        self.reply_panel.set_ai_enabled(configured)
        self.live_panel.set_ai_enabled(configured)
        host = provider_host(self._manager.settings)
        self.privacy_label.setText(
            f"Privacy: text is sent to {host} only when you click an action. "
            "Nothing is ever sent to Discord automatically; you review and send every message yourself."
        )

    def _open_settings(self) -> None:
        dialog = SettingsDialog(self._manager, self._secrets, self)
        if dialog.exec():
            self._refresh_state()
            self.toast.show_message("Settings saved.", "success")

    def _notify(self, kind: str, text: str) -> None:
        """Panels emit (kind, text); the toast takes (text, kind)."""
        self.toast.show_message(text, kind)

    def _on_auto_toggled(self, checked: bool) -> None:
        if checked and not self._auto_consented:
            host = provider_host(self._manager.settings)
            answer = QMessageBox.question(
                self,
                "Turn on auto-reply?",
                f"While this is on, ANYTHING you copy (Ctrl+C) is sent to {host} to get reply suggestions. "
                "Don't copy passwords or private info while it's on.\n\n"
                "Turn it off any time with the same checkbox. Nothing is ever sent to Discord.\n\nTurn it on?",
            )
            if answer != QMessageBox.Yes:
                self.message_panel.set_auto_checked(False)
                return
            self._auto_consented = True
        self.clip_watcher.set_active(checked)
        self._on_live_changed(self.live_panel.watcher.state == "running")
        self.reply_panel.set_status(
            "Auto-reply is ON. Select a message in Discord and press Ctrl+C."
            if checked else "Auto-reply is off."
        )

    def _on_message_copied(self, text: str) -> None:
        self.message_panel.set_text(text)
        self.reply_panel.analyze_text(text, self._manager.settings.my_name)
        QApplication.alert(self, 0)

    def _on_live_analysis(self, analysis: object) -> None:
        assert isinstance(analysis, Analysis)
        self.reply_panel.show_analysis(analysis)
        self.toast.show_message("New message. Replies are ready.", "success")
        QApplication.alert(self, 0)  # flash the taskbar without stealing focus

    def _on_live_changed(self, live: bool) -> None:
        live = live or self.clip_watcher.active
        self.setWindowTitle(f"\u25cf LIVE - {APP_NAME}" if live else APP_NAME)

    def closeEvent(self, event) -> None:
        self.live_panel.shutdown()
        super().closeEvent(event)

    def _toggle_pin(self, checked: bool) -> None:
        self.setWindowFlag(Qt.WindowStaysOnTopHint, checked)
        self.show()  # changing window flags hides the window
        self._manager.settings.always_on_top = checked
        self._manager.save()

    def _copy(self, text: str) -> None:
        self.clip_watcher.mark_own(text)
        try:
            copy_text(text)
        except ClipboardError as exc:
            self.toast.show_message(str(exc), "error")
            return
        self.toast.show_message("Copied. Paste it into Discord, check it, then send.", "success")

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if not self._title_bar_done:
            self._title_bar_done = True
            _enable_dark_title_bar(self)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "toast") and self.toast.isVisible():
            self.toast.reposition()
