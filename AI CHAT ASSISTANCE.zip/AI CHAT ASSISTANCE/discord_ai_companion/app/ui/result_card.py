"""One correction result: original, corrected, explanation, Copy button."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from app.services.ai_service import EditResult


def _text_label(text: str, object_name: str = "") -> QLabel:
    label = QLabel(text)
    label.setTextFormat(Qt.PlainText)  # never interpret AI output as HTML
    label.setWordWrap(True)
    label.setTextInteractionFlags(Qt.TextSelectableByMouse)
    if object_name:
        label.setObjectName(object_name)
    return label


def _field_label(text: str) -> QLabel:
    label = QLabel(text.upper())
    label.setObjectName("fieldLabel")
    return label


class ResultCard(QFrame):
    copyRequested = Signal(str)

    def __init__(self, action_name: str, result: EditResult) -> None:
        super().__init__()
        self.setObjectName("resultCard")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(4)

        head = QHBoxLayout()
        title = QLabel(action_name)
        title.setObjectName("sectionTitle")
        copy_btn = QPushButton("Copy")
        copy_btn.setProperty("variant", "primary")
        copy_btn.clicked.connect(lambda: self.copyRequested.emit(result.corrected))
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(copy_btn)
        layout.addLayout(head)

        layout.addWidget(_field_label("Original"))
        layout.addWidget(_text_label(result.original, "muted"))
        layout.addWidget(_field_label("Corrected"))
        layout.addWidget(_text_label(result.corrected, "corrected"))
        if result.explanation:
            layout.addWidget(_field_label("What changed"))
            layout.addWidget(_text_label(result.explanation))
