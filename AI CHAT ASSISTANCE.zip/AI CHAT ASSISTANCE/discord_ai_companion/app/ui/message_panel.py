"""Incoming message input: paste from clipboard, then Analyze."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QCheckBox, QFrame, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QVBoxLayout

from app.capture.clipboard_capture import ClipboardError, read_clipboard_text


class MessagePanel(QFrame):
    notify = Signal(str, str)
    analyzeRequested = Signal(str)
    autoReplyToggled = Signal(bool)

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("card")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)

        title = QLabel("Incoming Message")
        title.setObjectName("sectionTitle")
        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText("Copy a message in Discord, then paste it here...")
        self.editor.setFixedHeight(80)

        row = QHBoxLayout()
        self.paste_btn = QPushButton("Paste from clipboard")
        self.analyze_btn = QPushButton("Analyze")
        self.analyze_btn.setProperty("variant", "primary")
        self.clear_btn = QPushButton("Clear")
        for button in (self.paste_btn, self.analyze_btn, self.clear_btn):
            row.addWidget(button)
        row.addStretch(1)

        self.auto_box = QCheckBox("Auto-reply when I copy a message (select text in Discord, press Ctrl+C)")
        self.auto_box.toggled.connect(self.autoReplyToggled)

        layout.addWidget(title)
        layout.addWidget(self.auto_box)
        layout.addWidget(self.editor)
        layout.addLayout(row)

        self.paste_btn.clicked.connect(self._paste)
        self.clear_btn.clicked.connect(self.editor.clear)
        self.analyze_btn.clicked.connect(lambda: self.analyzeRequested.emit(self.text()))
        self.set_ai_enabled(False)

    def set_ai_enabled(self, enabled: bool) -> None:
        self.analyze_btn.setEnabled(enabled)
        self.auto_box.setEnabled(enabled)

    def set_auto_checked(self, checked: bool) -> None:
        self.auto_box.blockSignals(True)
        self.auto_box.setChecked(checked)
        self.auto_box.blockSignals(False)

    def set_text(self, text: str) -> None:
        self.editor.setPlainText(text)

    def text(self) -> str:
        return self.editor.toPlainText().strip()

    def _paste(self) -> None:
        try:
            text = read_clipboard_text()
        except ClipboardError as exc:
            self.notify.emit("error", str(exc))
            return
        if not text:
            self.notify.emit("error", "The clipboard has no text. Copy a message first.")
            return
        self.editor.setPlainText(text)
        self.notify.emit("success", "Message pasted.")
