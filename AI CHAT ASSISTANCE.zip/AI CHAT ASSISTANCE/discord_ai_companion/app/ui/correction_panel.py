"""English sentence correction: input box, six actions, result cards."""
from __future__ import annotations

from PySide6.QtCore import QThreadPool, Qt, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.services.ai_service import AIError, EditResult
from app.services.grammar_corrector import CorrectionAction, GrammarCorrector
from app.services.workers import Worker
from app.ui.result_card import ResultCard
from app.utils.validators import ValidationError, validate_sentence

MAX_RESULTS = 8


class CorrectionPanel(QFrame):
    notify = Signal(str, str)  # kind, text
    copyRequested = Signal(str)

    def __init__(self, corrector: GrammarCorrector) -> None:
        super().__init__()
        self.setObjectName("card")
        self._corrector = corrector
        self._pool = QThreadPool.globalInstance()
        self._ai_enabled = False
        self._busy = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel("Your Reply")
        title.setObjectName("sectionTitle")
        hint = QLabel("Type what you want to say. Ctrl+Enter = Correct Grammar.")
        hint.setObjectName("muted")

        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText("e.g. i dont know what to says to him")
        self.editor.setFixedHeight(90)

        grid = QGridLayout()
        grid.setSpacing(8)
        self._buttons: dict[CorrectionAction, QPushButton] = {}
        for index, action in enumerate(CorrectionAction):
            button = QPushButton(action.value)
            if action is CorrectionAction.CORRECT:
                button.setProperty("variant", "primary")
            button.clicked.connect(lambda _checked=False, a=action: self._run(a))
            self._buttons[action] = button
            grid.addWidget(button, index // 3, index % 3)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)  # indeterminate loading bar
        self.progress.setTextVisible(False)
        self.progress.hide()

        self.setup_hint = QLabel("AI isn't set up yet. Open Settings to add an API key.")
        self.setup_hint.setObjectName("muted")
        self.setup_hint.setWordWrap(True)

        self.results_layout = QVBoxLayout()
        self.results_layout.setSpacing(10)
        self.results_layout.addStretch(1)
        inner = QWidget()
        inner.setLayout(self.results_layout)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)

        layout.addWidget(title)
        layout.addWidget(hint)
        layout.addWidget(self.editor)
        layout.addLayout(grid)
        layout.addWidget(self.progress)
        layout.addWidget(self.setup_hint)
        layout.addWidget(scroll, 1)

        shortcut = QShortcut(QKeySequence("Ctrl+Return"), self.editor)
        shortcut.setContext(Qt.WidgetShortcut)
        shortcut.activated.connect(lambda: self._run(CorrectionAction.CORRECT))
        self._update_buttons()

    # ---- state -----------------------------------------------------------
    def set_ai_enabled(self, enabled: bool) -> None:
        self._ai_enabled = enabled
        self.setup_hint.setVisible(not enabled)
        self._update_buttons()

    def set_text(self, text: str) -> None:
        self.editor.setPlainText(text)

    def _update_buttons(self) -> None:
        for button in self._buttons.values():
            button.setEnabled(self._ai_enabled and not self._busy)

    # ---- actions -----------------------------------------------------------
    def _run(self, action: CorrectionAction) -> None:
        if self._busy or not self._ai_enabled:
            return
        try:
            sentence = validate_sentence(self.editor.toPlainText())
        except ValidationError as exc:
            self.notify.emit("error", str(exc))
            return
        self._busy = True
        self.progress.show()
        self._update_buttons()

        def job() -> tuple[CorrectionAction, EditResult]:
            return action, self._corrector.run(action, sentence)

        worker = Worker(job)
        worker.signals.result.connect(self._on_result)
        worker.signals.error.connect(self._on_error)
        worker.signals.finished.connect(self._on_finished)
        self._pool.start(worker)

    def _on_result(self, payload: object) -> None:
        action, result = payload  # type: ignore[misc]
        card = ResultCard(action.value, result)
        card.copyRequested.connect(self.copyRequested)
        self.results_layout.insertWidget(0, card)
        while self.results_layout.count() - 1 > MAX_RESULTS:
            item = self.results_layout.takeAt(self.results_layout.count() - 2)
            if item and item.widget():
                item.widget().deleteLater()

    def _on_error(self, exc: object) -> None:
        if isinstance(exc, AIError):
            self.notify.emit("error", exc.message)
        elif isinstance(exc, ValidationError):
            self.notify.emit("error", str(exc))
        else:
            self.notify.emit("error", "Something went wrong. Please try again.")

    def _on_finished(self) -> None:
        self._busy = False
        self.progress.hide()
        self._update_buttons()
