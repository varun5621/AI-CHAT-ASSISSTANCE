"""Shows what the incoming message means and three reply options with Copy buttons."""
from __future__ import annotations

from PySide6.QtCore import QThreadPool, Signal
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

from app.services.ai_service import AIError
from app.services.message_analyzer import STANDARD_TONE, TONES, Analysis, MessageAnalyzer
from app.services.workers import Worker
from app.ui.result_card import _field_label, _text_label
from app.utils.validators import ValidationError


class ReplyPanel(QFrame):
    notify = Signal(str, str)
    copyRequested = Signal(str)

    def __init__(self, analyzer: MessageAnalyzer) -> None:
        super().__init__()
        self.setObjectName("card")
        self._analyzer = analyzer
        self._pool = QThreadPool.globalInstance()
        self._ai_enabled = False
        self._req = 0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(8)

        head = QHBoxLayout()
        title = QLabel("Suggested Replies")
        title.setObjectName("sectionTitle")
        self.tone_box = QComboBox()
        self.tone_box.addItems(TONES)
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(QLabel("Tone"))
        head.addWidget(self.tone_box)
        layout.addLayout(head)

        self.status = QLabel("Paste a message and click Analyze, or start Live watch.")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.hide()
        layout.addWidget(self.status)
        layout.addWidget(self.progress)

        self.body = QVBoxLayout()
        self.body.setSpacing(8)
        self.body.addStretch(1)
        inner = QWidget()
        inner.setLayout(self.body)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)
        layout.addWidget(scroll, 1)
        self.setMinimumHeight(260)

    def tone(self) -> str:
        return self.tone_box.currentText() or STANDARD_TONE

    def set_ai_enabled(self, enabled: bool) -> None:
        self._ai_enabled = enabled

    def set_status(self, text: str) -> None:
        self.status.setText(text)

    # ---- pasted-message analysis -----------------------------------------
    def analyze_text(self, text: str, my_name: str) -> None:
        if not self._ai_enabled:
            self.notify.emit("error", "Set up an AI provider in Settings first.")
            return
        self.progress.show()
        self.status.setText("Reading the message...")
        self._req += 1
        req, tone = self._req, self.tone()

        def job() -> tuple[int, Analysis]:
            return req, self._analyzer.analyze_message(text, tone, my_name)

        worker = Worker(job)
        worker.signals.result.connect(self._on_result)
        worker.signals.error.connect(self._on_error)
        worker.signals.finished.connect(self.progress.hide)
        self._pool.start(worker)

    def _on_result(self, payload: object) -> None:
        req, analysis = payload  # type: ignore[misc]
        if req == self._req:  # a newer request is running; drop the old answer
            self.show_analysis(analysis)

    def _on_error(self, exc: object) -> None:
        self.status.setText("")
        if isinstance(exc, (AIError, ValidationError)):
            self.notify.emit("error", getattr(exc, "message", str(exc)))
        else:
            self.notify.emit("error", "Something went wrong. Please try again.")

    # ---- rendering ---------------------------------------------------------
    def show_analysis(self, analysis: Analysis) -> None:
        while self.body.count() > 1:
            item = self.body.takeAt(0)
            if item and item.widget():
                item.widget().deleteLater()
        if not analysis.needs_reply:
            self.status.setText(analysis.meaning or "Nothing to reply to right now.")
            return
        who = f"{analysis.author}: " if analysis.author else ""
        self.status.setText(f"{who}{analysis.incoming}")
        pos = 0
        pos = self._add(pos, _field_label("What it means"))
        pos = self._add(pos, _text_label(analysis.meaning))
        if analysis.slang:
            pos = self._add(pos, _field_label("Slang"))
            for term, meaning in analysis.slang:
                pos = self._add(pos, _text_label(f"{term}: {meaning}"))
        for reply in analysis.replies:
            pos = self._add(pos, self._reply_card(reply.label, reply.text))

    def _add(self, pos: int, widget: QWidget) -> int:
        self.body.insertWidget(pos, widget)
        return pos + 1

    def _reply_card(self, label: str, text: str) -> QFrame:
        card = QFrame()
        card.setObjectName("resultCard")
        row = QHBoxLayout(card)
        row.setContentsMargins(14, 10, 14, 10)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(_field_label(label))
        col.addWidget(_text_label(text, "corrected"))
        button = QPushButton("Copy")
        button.setProperty("variant", "primary")
        button.clicked.connect(lambda: self.copyRequested.emit(text))
        row.addLayout(col, 1)
        row.addWidget(button)
        return card
