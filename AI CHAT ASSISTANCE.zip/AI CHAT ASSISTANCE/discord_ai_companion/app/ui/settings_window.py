"""Settings dialog: provider, endpoint, model, API key, creativity, connection test."""
from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSlider,
    QVBoxLayout,
)

from app.services.ai_service import AIError, AIService
from app.services.workers import Worker
from app.storage.settings_manager import (
    PROVIDER_ANTHROPIC,
    PROVIDER_DEFAULTS,
    PROVIDER_OPENAI,
    SecretStore,
    Settings,
    SettingsManager,
)
from app.utils.validators import ValidationError, validate_base_url


class SettingsDialog(QDialog):
    def __init__(self, manager: SettingsManager, secrets: SecretStore, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.setMinimumWidth(520)
        self._manager = manager
        self._secrets = secrets
        self._prev_provider = manager.settings.provider
        self._pool = QThreadPool.globalInstance()

        s = manager.settings
        self.provider = QComboBox()
        self.provider.addItem("OpenAI-compatible (OpenAI, OpenRouter, Ollama, LM Studio)", PROVIDER_OPENAI)
        self.provider.addItem("Anthropic (Claude)", PROVIDER_ANTHROPIC)
        self.provider.setCurrentIndex(max(0, self.provider.findData(s.provider)))

        self.base_url = QLineEdit(s.base_url)
        self.model = QLineEdit(s.model)

        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.Password)
        self._refresh_key_placeholder()

        self.creativity = QSlider(Qt.Horizontal)
        self.creativity.setRange(0, 100)
        self.creativity.setValue(int(s.temperature * 100))
        self.creativity_label = QLabel()
        self.creativity.valueChanged.connect(self._update_creativity_label)
        self._update_creativity_label()
        creativity_row = QHBoxLayout()
        creativity_row.addWidget(self.creativity, 1)
        creativity_row.addWidget(self.creativity_label)

        form = QFormLayout()
        form.setSpacing(10)
        form.addRow("AI provider", self.provider)
        form.addRow("Base URL", self.base_url)
        form.addRow("Model", self.model)
        form.addRow("API key", self.api_key)
        form.addRow("Creativity", creativity_row)

        privacy = QLabel(
            "Privacy: text is sent to the provider above only when you click an action. "
            "Your key is stored locally and never shown or logged. "
            "For a fully local setup, use Ollama with base URL http://localhost:11434/v1 (no key needed)."
        )
        privacy.setObjectName("muted")
        privacy.setWordWrap(True)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.PlainText)

        self.test_btn = QPushButton("Test connection")
        self.clear_key_btn = QPushButton("Remove saved key")
        self.save_btn = QPushButton("Save")
        self.save_btn.setProperty("variant", "primary")
        cancel_btn = QPushButton("Cancel")
        buttons = QHBoxLayout()
        buttons.addWidget(self.test_btn)
        buttons.addWidget(self.clear_key_btn)
        buttons.addStretch(1)
        buttons.addWidget(cancel_btn)
        buttons.addWidget(self.save_btn)

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 18)
        root.setSpacing(12)
        root.addLayout(form)
        root.addWidget(privacy)
        root.addWidget(self.status)
        root.addLayout(buttons)

        self.provider.currentIndexChanged.connect(self._on_provider_changed)
        self.test_btn.clicked.connect(self._test)
        self.clear_key_btn.clicked.connect(self._clear_key)
        self.save_btn.clicked.connect(self._save)
        cancel_btn.clicked.connect(self.reject)

    # ---- helpers -----------------------------------------------------------
    def _refresh_key_placeholder(self) -> None:
        saved = self._secrets.get_api_key() is not None
        self.api_key.setPlaceholderText(
            "A key is saved. Leave blank to keep it." if saved else "Paste your API key here"
        )

    def _update_creativity_label(self) -> None:
        self.creativity_label.setText(f"{self.creativity.value() / 100:.2f}")

    def _on_provider_changed(self) -> None:
        new = self.provider.currentData()
        old_url, old_model = PROVIDER_DEFAULTS[self._prev_provider]
        if self.base_url.text().strip().rstrip("/") == old_url:
            self.base_url.setText(PROVIDER_DEFAULTS[new][0])
        if self.model.text().strip() == old_model:
            self.model.setText(PROVIDER_DEFAULTS[new][1])
        self._prev_provider = new

    def _form_settings(self) -> Settings:
        return replace(
            self._manager.settings,
            provider=self.provider.currentData(),
            base_url=validate_base_url(self.base_url.text()),
            model=self.model.text().strip() or PROVIDER_DEFAULTS[self.provider.currentData()][1],
            temperature=self.creativity.value() / 100,
        )

    def _set_status(self, text: str, ok: bool) -> None:
        self.status.setStyleSheet(f"color: {'#4cc38a' if ok else '#ef6b7b'};")
        self.status.setText(text)

    # ---- actions -----------------------------------------------------------
    def _test(self) -> None:
        try:
            candidate = self._form_settings()
        except ValidationError as exc:
            self._set_status(str(exc), False)
            return
        typed = self.api_key.text().strip()
        service = AIService(lambda: candidate, lambda: typed or self._secrets.get_api_key())
        self.test_btn.setEnabled(False)
        self._set_status("Testing...", True)
        worker = Worker(service.test_connection)
        worker.signals.result.connect(self._on_test_ok)
        worker.signals.error.connect(self._on_test_error)
        worker.signals.finished.connect(self._on_test_done)
        self._pool.start(worker)

    def _on_test_ok(self, _result: object) -> None:
        self._set_status("Connected. The AI answered.", True)

    def _on_test_error(self, exc: object) -> None:
        self._set_status(exc.message if isinstance(exc, AIError) else "Test failed. Check your settings.", False)

    def _on_test_done(self) -> None:
        self.test_btn.setEnabled(True)

    def _clear_key(self) -> None:
        self._secrets.clear_api_key()
        self.api_key.clear()
        self._refresh_key_placeholder()
        self._set_status("Saved key removed.", True)

    def _save(self) -> None:
        try:
            new_settings = self._form_settings()
            typed = self.api_key.text().strip()
            if typed:
                self._secrets.set_api_key(typed)
        except (ValidationError, ValueError) as exc:
            self._set_status(str(exc), False)
            return
        self._manager.settings = new_settings
        self._manager.save()
        self.accept()
