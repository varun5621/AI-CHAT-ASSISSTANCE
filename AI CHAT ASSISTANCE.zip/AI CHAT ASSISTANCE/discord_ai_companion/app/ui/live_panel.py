"""Live watch controls: pick the chat area, start/pause/stop, visible LIVE indicator."""
from __future__ import annotations

from PySide6.QtCore import QTimer, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
)

from app.capture.region_capture import Region, RegionSelector
from app.services.live_watcher import LiveWatcher
from app.services.message_analyzer import MessageAnalyzer
from app.storage.settings_manager import SettingsManager, provider_host


class LivePanel(QFrame):
    analysisReady = Signal(object)
    liveChanged = Signal(bool)
    notify = Signal(str, str)
    statusChanged = Signal(str)

    def __init__(self, manager: SettingsManager, analyzer: MessageAnalyzer, tone_getter) -> None:
        super().__init__()
        self.setObjectName("card")
        self._manager = manager
        self._region: Region | None = None
        self._ai_enabled = False
        self._consented = False
        self._selectors: list[RegionSelector] = []
        self.watcher = LiveWatcher(analyzer, lambda: manager.settings.my_name, tone_getter)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)

        head = QHBoxLayout()
        title = QLabel("Live Watch")
        title.setObjectName("sectionTitle")
        self.indicator = QLabel()
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(self.indicator)
        layout.addLayout(head)

        self.region_label = QLabel("No chat area selected. Put Discord next to this window, then click Select chat area.")
        self.region_label.setObjectName("muted")
        self.region_label.setWordWrap(True)
        layout.addWidget(self.region_label)

        buttons = QHBoxLayout()
        self.select_btn = QPushButton("Select chat area")
        self.start_btn = QPushButton("Start live")
        self.start_btn.setProperty("variant", "primary")
        self.pause_btn = QPushButton("Pause")
        self.stop_btn = QPushButton("Stop")
        for b in (self.select_btn, self.start_btn, self.pause_btn, self.stop_btn):
            buttons.addWidget(b)
        layout.addLayout(buttons)

        options = QHBoxLayout()
        self.name_edit = QLineEdit(manager.settings.my_name)
        self.name_edit.setPlaceholderText("Your Discord name (so I skip your own messages)")
        self.interval = QSpinBox()
        self.interval.setRange(2, 15)
        self.interval.setSuffix(" s")
        self.interval.setValue(manager.settings.live_interval_s)
        options.addWidget(self.name_edit, 1)
        options.addWidget(QLabel("Check every"))
        options.addWidget(self.interval)
        layout.addLayout(options)

        self.select_btn.clicked.connect(self._select)
        self.start_btn.clicked.connect(self._start)
        self.pause_btn.clicked.connect(self._toggle_pause)
        self.stop_btn.clicked.connect(lambda: self.watcher.stop("Live watch stopped."))
        self.name_edit.editingFinished.connect(self._save_options)
        self.interval.editingFinished.connect(self._save_options)

        self.watcher.analysis_ready.connect(self.analysisReady)
        self.watcher.status.connect(self.statusChanged)
        self.watcher.stopped.connect(self._on_stopped)
        self.watcher.state_changed.connect(self._apply_state)
        self._apply_state("idle")

    # ---- state -------------------------------------------------------------
    def set_ai_enabled(self, enabled: bool) -> None:
        self._ai_enabled = enabled
        self._apply_state(self.watcher.state)

    def _apply_state(self, state: str) -> None:
        idle = state == "idle"
        self.select_btn.setEnabled(idle)
        self.start_btn.setEnabled(idle and self._region is not None and self._ai_enabled)
        self.pause_btn.setEnabled(not idle)
        self.stop_btn.setEnabled(not idle)
        self.pause_btn.setText("Resume" if state == "paused" else "Pause")
        self.name_edit.setEnabled(idle)
        self.interval.setEnabled(idle)
        if state == "running":
            self.indicator.setText("\u25cf LIVE")
            self.indicator.setStyleSheet("color: #ef6b7b; font-weight: 700;")
        elif state == "paused":
            self.indicator.setText("Paused")
            self.indicator.setStyleSheet("color: #e5b567; font-weight: 700;")
        else:
            self.indicator.setText("Not watching")
            self.indicator.setStyleSheet("color: #9496ad;")
        self.liveChanged.emit(state == "running")

    def _save_options(self) -> None:
        s = self._manager.settings
        s.my_name = self.name_edit.text().strip()
        s.live_interval_s = self.interval.value()
        self._manager.save()

    # ---- actions -----------------------------------------------------------
    def _select(self) -> None:
        self.window().hide()  # so Discord is visible on the frozen screenshot
        QTimer.singleShot(350, self._open_selectors)

    def _open_selectors(self) -> None:
        self._selectors = []
        for screen in QGuiApplication.screens():
            selector = RegionSelector(screen)
            selector.selected.connect(self._on_selected)
            selector.cancelled.connect(self._on_cancelled)
            self._selectors.append(selector)
            selector.showFullScreen()
        if self._selectors:
            self._selectors[0].activateWindow()

    def _close_selectors(self) -> None:
        for selector in self._selectors:
            selector.close()
        self._selectors = []
        win = self.window()
        win.show()
        win.raise_()
        win.activateWindow()

    def _on_selected(self, region: object) -> None:
        self._region = region  # type: ignore[assignment]
        self._close_selectors()
        self.region_label.setText(
            f"Chat area selected ({self._region.describe()} px). Keep this app window outside that area."
        )
        self._apply_state(self.watcher.state)

    def _on_cancelled(self) -> None:
        self._close_selectors()

    def _start(self) -> None:
        if self._region is None:
            return
        if not self._consented:
            host = provider_host(self._manager.settings)
            answer = QMessageBox.question(
                self,
                "Start live watch?",
                f"While live, a screenshot of ONLY the area you selected is sent to {host} each time it "
                "changes. Anyone or anything visible in that area is included.\n\n"
                "You can pause or stop at any time. Nothing is ever sent to Discord; you copy and send "
                "every reply yourself.\n\nContinue?",
            )
            if answer != QMessageBox.Yes:
                return
            self._consented = True
        self._save_options()
        self.watcher.start(self._region, self.interval.value())

    def _toggle_pause(self) -> None:
        if self.watcher.state == "running":
            self.watcher.pause()
        else:
            self.watcher.resume()

    def _on_stopped(self, reason: str) -> None:
        if reason:
            self.notify.emit("info" if reason == "Live watch stopped." else "error", reason)
        self.statusChanged.emit("Live watch is off.")

    def shutdown(self) -> None:
        if self.watcher.state != "idle":
            self.watcher.stop()
