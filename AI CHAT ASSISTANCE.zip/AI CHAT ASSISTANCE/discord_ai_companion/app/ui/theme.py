"""Dark charcoal theme with purple/blue accents."""
BG = "#16171c"
CARD = "#1f2027"
CARD_ALT = "#272833"
BORDER = "#33354a"
TEXT = "#e9eaf2"
MUTED = "#9496ad"
PURPLE = "#8b7cf6"
BLUE = "#5b8def"
DANGER = "#ef6b7b"
SUCCESS = "#4cc38a"

STYLESHEET = f"""
* {{ font-family: "Segoe UI", "Inter", sans-serif; font-size: 13px; color: {TEXT}; }}
QMainWindow, QDialog, QWidget#root {{ background: {BG}; }}
QLabel {{ background: transparent; }}
QLabel#title {{ font-size: 20px; font-weight: 700; }}
QLabel#subtitle, QLabel#muted {{ color: {MUTED}; }}
QLabel#sectionTitle {{ font-size: 15px; font-weight: 600; }}
QLabel#fieldLabel {{ color: {MUTED}; font-size: 11px; font-weight: 600; }}
QLabel#corrected {{ font-size: 15px; }}
QFrame#card {{ background: {CARD}; border: 1px solid {BORDER}; border-radius: 14px; }}
QFrame#resultCard {{ background: {CARD_ALT}; border: 1px solid {BORDER}; border-radius: 12px; }}
QFrame#banner {{ background: #2a2640; border: 1px solid {PURPLE}; border-radius: 12px; }}
QPlainTextEdit, QLineEdit, QComboBox {{
    background: {BG}; border: 1px solid {BORDER}; border-radius: 10px; padding: 8px;
    selection-background-color: {PURPLE};
}}
QPlainTextEdit:focus, QLineEdit:focus, QComboBox:focus {{ border: 1px solid {PURPLE}; }}
QComboBox QAbstractItemView {{ background: {CARD}; selection-background-color: {PURPLE}; }}
QPushButton {{
    background: {CARD_ALT}; border: 1px solid {BORDER}; border-radius: 10px; padding: 8px 14px;
}}
QPushButton:hover {{ border: 1px solid {PURPLE}; }}
QPushButton:disabled {{ color: #666881; background: {CARD}; border: 1px solid {CARD_ALT}; }}
QPushButton:checked {{ border: 1px solid {PURPLE}; background: #2d2a4a; }}
QPushButton[variant="primary"] {{
    border: none; font-weight: 600;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {PURPLE}, stop:1 {BLUE});
}}
QPushButton[variant="primary"]:hover {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #9d90ff, stop:1 #70a0ff); }}
QPushButton[variant="primary"]:disabled {{ background: {CARD_ALT}; color: #666881; }}
QProgressBar {{ background: {BG}; border: none; border-radius: 2px; max-height: 4px; }}
QProgressBar::chunk {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {PURPLE}, stop:1 {BLUE}); border-radius: 2px; }}
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
#qt_scrollarea_viewport {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 5px; min-height: 24px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QSplitter::handle {{ background: transparent; }}
QSlider::groove:horizontal {{ height: 4px; background: {BORDER}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {PURPLE}; width: 14px; margin: -6px 0; border-radius: 7px; }}
QLabel#toast {{ border-radius: 10px; padding: 10px 16px; background: {CARD_ALT}; border: 1px solid {BORDER}; }}
QLabel#toast[kind="success"] {{ border: 1px solid {SUCCESS}; }}
QLabel#toast[kind="error"] {{ border: 1px solid {DANGER}; }}
"""
