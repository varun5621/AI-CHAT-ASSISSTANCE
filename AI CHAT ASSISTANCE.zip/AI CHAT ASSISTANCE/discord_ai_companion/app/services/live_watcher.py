"""Watches a user-selected screen region and asks the AI for replies when a new message appears."""
from __future__ import annotations

import re
from typing import Callable

from PySide6.QtCore import QObject, QThreadPool, QTimer, Signal

from app.capture.region_capture import Region, encode_jpeg, grab_region, signature
from app.services.ai_service import AIError, AIErrorKind
from app.services.message_analyzer import Analysis, MessageAnalyzer
from app.services.workers import Worker

MAX_CONSECUTIVE_ERRORS = 3
FATAL_KINDS = {AIErrorKind.AUTH, AIErrorKind.NOT_CONFIGURED, AIErrorKind.RATE_LIMIT, AIErrorKind.BAD_REQUEST}


def _normalize(text: str) -> str:
    return re.sub(r"\W+", " ", text.lower()).strip()


class LiveWatcher(QObject):
    analysis_ready = Signal(object)
    status = Signal(str)
    stopped = Signal(str)
    state_changed = Signal(str)  # "idle" | "running" | "paused"

    def __init__(
        self,
        analyzer: MessageAnalyzer,
        my_name_getter: Callable[[], str],
        tone_getter: Callable[[], str],
        grab: Callable[[Region], object] = grab_region,
    ) -> None:
        super().__init__()
        self._analyzer = analyzer
        self._my_name = my_name_getter
        self._tone = tone_getter
        self._grab = grab
        self._pool = QThreadPool.globalInstance()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self.state = "idle"
        self._region: Region | None = None
        self._busy = False
        self._last_sig: bytes | None = None
        self._pending = False
        self._last_key = ""
        self._errors = 0
        self.calls = 0

    # ---- controls ----------------------------------------------------------
    def start(self, region: Region, interval_s: int) -> None:
        self._region = region
        self._last_sig = None
        self._pending = True
        self._last_key = ""
        self._errors = 0
        self.calls = 0
        self._set_state("running")
        self._timer.start(max(2, interval_s) * 1000)
        self.status.emit("Watching the chat area...")

    def pause(self) -> None:
        self._timer.stop()
        self._set_state("paused")
        self.status.emit("Paused. Nothing is being captured.")

    def resume(self) -> None:
        if self._region is None:
            return
        self._pending = True
        self._set_state("running")
        self._timer.start()
        self.status.emit("Watching the chat area...")

    def stop(self, reason: str = "") -> None:
        self._timer.stop()
        self._set_state("idle")
        self.stopped.emit(reason)

    def _set_state(self, state: str) -> None:
        self.state = state
        self.state_changed.emit(state)

    # ---- loop --------------------------------------------------------------
    def _tick(self) -> None:
        if self._busy or self._region is None or self.state != "running":
            return
        try:
            image = self._grab(self._region)
        except Exception:
            self.stop("Couldn't capture the selected area. Select it again.")
            return
        if image.isNull():
            return
        sig = signature(image)
        if sig != self._last_sig:
            self._last_sig = sig
            self._pending = True  # something changed; wait one tick for it to settle
            return
        if self._pending:
            self._pending = False
            self._submit(image)

    def _submit(self, image) -> None:
        self._busy = True
        self.calls += 1
        self.status.emit(f"Reading the chat... (AI calls this session: {self.calls})")
        worker = Worker(self._analyzer.analyze_image, encode_jpeg(image), self._tone(), self._my_name())
        worker.signals.result.connect(self._on_result)
        worker.signals.error.connect(self._on_error)
        worker.signals.finished.connect(self._on_finished)
        self._pool.start(worker)

    def _on_result(self, analysis: object) -> None:
        if self.state == "idle":
            return
        assert isinstance(analysis, Analysis)
        self._errors = 0
        if not analysis.needs_reply:
            self.status.emit("Waiting for a new message from someone else.")
            return
        key = _normalize(analysis.author + " " + analysis.incoming)
        if key == self._last_key:
            self.status.emit("No new message yet.")
            return
        self._last_key = key
        self.status.emit("New message. Replies are ready.")
        self.analysis_ready.emit(analysis)

    def _on_error(self, exc: object) -> None:
        if self.state == "idle":
            return
        message = exc.message if isinstance(exc, AIError) else "Something went wrong reading the chat."
        if isinstance(exc, AIError) and exc.kind in FATAL_KINDS:
            self.stop(message)
            return
        self._errors += 1
        if self._errors >= MAX_CONSECUTIVE_ERRORS:
            self.stop(f"Stopped after {MAX_CONSECUTIVE_ERRORS} failures in a row. {message}")
        else:
            self.status.emit(message)

    def _on_finished(self) -> None:
        self._busy = False
