"""Run blocking work (AI calls, later OCR) off the UI thread."""
from __future__ import annotations

from typing import Any, Callable

from PySide6.QtCore import QObject, QRunnable, Signal


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(object)
    finished = Signal()


class Worker(QRunnable):
    def __init__(self, fn: Callable[..., Any], *args: Any) -> None:
        super().__init__()
        self._fn = fn
        self._args = args
        self.signals = WorkerSignals()

    def run(self) -> None:
        try:
            self.signals.result.emit(self._fn(*self._args))
        except Exception as exc:  # surfaced to the UI, never crashes the thread
            self.signals.error.emit(exc)
        finally:
            self.signals.finished.emit()
