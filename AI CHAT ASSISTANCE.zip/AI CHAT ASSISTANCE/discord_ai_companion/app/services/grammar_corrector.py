"""Maps the six correction buttons onto AI operations."""
from __future__ import annotations

from enum import Enum

from app.services.ai_service import AIService, EditResult
from app.utils.validators import validate_sentence


class CorrectionAction(Enum):
    CORRECT = "Correct Grammar"
    NATURAL = "Make It Natural"
    CASUAL = "Make It Casual"
    SHORTER = "Make It Shorter"
    VOCABULARY = "Improve Vocabulary"
    EXPLAIN = "Explain My Mistakes"


class GrammarCorrector:
    def __init__(self, ai: AIService) -> None:
        self._ai = ai

    def run(self, action: CorrectionAction, sentence: str) -> EditResult:
        text = validate_sentence(sentence)
        if action is CorrectionAction.CORRECT:
            return self._ai.correct_sentence(text)
        if action is CorrectionAction.EXPLAIN:
            return self._ai.explain_grammar(text)
        style = {
            CorrectionAction.NATURAL: "natural",
            CorrectionAction.CASUAL: "casual",
            CorrectionAction.SHORTER: "shorter",
            CorrectionAction.VOCABULARY: "vocabulary",
        }[action]
        return self._ai.improve_sentence(text, style)
