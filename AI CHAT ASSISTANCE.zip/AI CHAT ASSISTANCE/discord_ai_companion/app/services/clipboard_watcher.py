"""Notices when the user copies a message (select text in Discord, press Ctrl+C)."""
from __future__ import annotations

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtGui import QGuiApplication

from app.utils.validators import MAX_SENTENCE_CHARS

MIN_CHARS = 2


class ClipboardWatcher(QObject):
    textCopied = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._clipboard = QGuiApplication.clipboard()
        self._active = False
        self._last = ""
        self._own = ""
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(400)  # let the copy settle before reading
        self._timer.timeout.connect(self._emit_if_new)
        self._clipboard.dataChanged.connect(self._on_changed)

    @property
    def active(self) -> bool:
        return self._active

    def set_active(self, active: bool) -> None:
        self._active = active
        if active:
            # whatever is on the clipboard right now was copied before, so don't analyze it
            self._last = (self._clipboard.text() or "").strip()

    def mark_own(self, text: str) -> None:
        """Call when the app itself copies text (Copy buttons) so it isn't treated as a new message."""
        self._own = text.strip()

    def _on_changed(self) -> None:
        if self._active:
            self._timer.start()

    def _emit_if_new(self) -> None:
        text = (self._clipboard.text() or "").strip()
        if not self._active or not (MIN_CHARS <= len(text) <= MAX_SENTENCE_CHARS):
            return
        if text == self._last or text == self._own:
            return
        self._last = text
        self.textCopied.emit(text)
