"""Discord AI Chat Companion entry point."""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from app import APP_NAME
from app.services.ai_service import AIService
from app.services.grammar_corrector import GrammarCorrector
from app.storage.settings_manager import SecretStore, SettingsManager, data_dir, load_dotenv
from app.ui.main_window import MainWindow
from app.ui.theme import STYLESHEET
from app.utils.logging_config import setup_logging


def main() -> int:
    folder = data_dir()
    setup_logging(folder / "logs")

    # Priority: real environment variable > key saved in Settings > project .env
    secrets_path = folder / "secrets.env"
    load_dotenv(secrets_path)
    load_dotenv(Path(__file__).resolve().parent / ".env")

    manager = SettingsManager(folder / "settings.json")
    secrets = SecretStore(secrets_path)
    ai = AIService(lambda: manager.settings, secrets.get_api_key)
    corrector = GrammarCorrector(ai)

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(STYLESHEET)

    window = MainWindow(manager, secrets, ai, corrector)
    window.show()
    logging.getLogger(__name__).info("App started")
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
