import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app.services.clipboard_watcher import ClipboardWatcher  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def test_copy_detection(qapp):
    w = ClipboardWatcher()
    got = []
    w.textCopied.connect(got.append)
    clip = QApplication.clipboard()

    clip.setText("old text"); w.set_active(True); w._emit_if_new()
    assert got == []                       # existing clipboard is ignored
    clip.setText("wyd tonight?"); w._emit_if_new()
    assert got == ["wyd tonight?"]
    w._emit_if_new()
    assert len(got) == 1                   # same text isn't analyzed twice
    w.mark_own("nm, you?"); clip.setText("nm, you?"); w._emit_if_new()
    assert len(got) == 1                   # the app's own Copy button is ignored
    clip.setText("x"); w._emit_if_new()
    assert len(got) == 1                   # too short
    w.set_active(False); clip.setText("new message here"); w._emit_if_new()
    assert len(got) == 1                   # off means off
