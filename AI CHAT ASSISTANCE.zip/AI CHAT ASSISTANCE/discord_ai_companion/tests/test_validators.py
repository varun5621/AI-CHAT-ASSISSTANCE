import pytest

from app.utils.validators import ValidationError, is_local_url, validate_base_url, validate_sentence


def test_sentence_trimmed():
    assert validate_sentence("  hi there  ") == "hi there"


@pytest.mark.parametrize("bad", ["", "   ", None])
def test_sentence_empty_rejected(bad):
    with pytest.raises(ValidationError):
        validate_sentence(bad)


def test_sentence_too_long():
    with pytest.raises(ValidationError):
        validate_sentence("a" * 2001)


def test_base_url():
    assert validate_base_url("https://api.openai.com/v1/") == "https://api.openai.com/v1"
    with pytest.raises(ValidationError):
        validate_base_url("api.openai.com")


def test_is_local_url():
    assert is_local_url("http://localhost:11434/v1")
    assert not is_local_url("https://api.openai.com/v1")
