import io
import urllib.error

import pytest

from app.services.ai_service import AIError, AIErrorKind, AIService, parse_edit_response
from app.storage.settings_manager import PROVIDER_ANTHROPIC, Settings


def make(settings=None, key="sk-test-123456789"):
    s = settings or Settings()
    return AIService(lambda: s, lambda: key)


def test_parse_plain_json():
    r = parse_edit_response('{"corrected": "I don\'t know.", "explanation": "dont -> don\'t"}', "i dont know")
    assert r.corrected == "I don't know." and r.original == "i dont know"


def test_parse_fenced_and_chatty_json():
    r = parse_edit_response('Sure!\n```json\n{"corrected": "Hi", "explanation": ["a", "b"]}\n```', "hi")
    assert r.corrected == "Hi" and r.explanation == "a\nb"


@pytest.mark.parametrize("bad", ["", "no json here", '{"explanation": "x"}', '{"corrected": ""}', "[1,2]"])
def test_parse_invalid(bad):
    with pytest.raises(AIError) as exc:
        parse_edit_response(bad, "x")
    assert exc.value.kind is AIErrorKind.INVALID_RESPONSE


def test_not_configured():
    with pytest.raises(AIError) as exc:
        make(key=None).correct_sentence("hi")
    assert exc.value.kind is AIErrorKind.NOT_CONFIGURED


def test_openai_flow(monkeypatch):
    seen = {}

    def fake_post(self, url, headers, payload, timeout):
        seen.update(url=url, headers=headers, payload=payload)
        return {"choices": [{"message": {"content": '{"corrected": "Hello", "explanation": ""}'}}]}

    monkeypatch.setattr(AIService, "_post_json", fake_post)
    result = make().correct_sentence("helo")
    assert result.corrected == "Hello"
    assert seen["url"].endswith("/chat/completions")
    assert "<user_text>" in seen["payload"]["messages"][1]["content"]


def test_anthropic_flow(monkeypatch):
    seen = {}

    def fake_post(self, url, headers, payload, timeout):
        seen.update(url=url, headers=headers)
        return {"content": [{"type": "text", "text": '{"corrected": "Hello", "explanation": "ok"}'}]}

    monkeypatch.setattr(AIService, "_post_json", fake_post)
    s = Settings(provider=PROVIDER_ANTHROPIC, base_url="https://api.anthropic.com", model="m")
    assert make(s).improve_sentence("helo", "casual").corrected == "Hello"
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["headers"]["x-api-key"] == "sk-test-123456789"


def test_unknown_style_rejected():
    with pytest.raises(ValueError):
        make().improve_sentence("hi", "pirate")


@pytest.mark.parametrize("code,kind", [
    (401, AIErrorKind.AUTH), (429, AIErrorKind.RATE_LIMIT),
    (503, AIErrorKind.SERVER), (400, AIErrorKind.BAD_REQUEST),
])
def test_http_errors(monkeypatch, code, kind):
    def boom(*a, **k):
        raise urllib.error.HTTPError("u", code, "x", {}, io.BytesIO(b'{"error": {"message": "nope"}}'))

    monkeypatch.setattr("urllib.request.urlopen", boom)
    with pytest.raises(AIError) as exc:
        make().correct_sentence("hi")
    assert exc.value.kind is kind


def test_network_error(monkeypatch):
    def boom(*a, **k):
        raise urllib.error.URLError("offline")

    monkeypatch.setattr("urllib.request.urlopen", boom)
    with pytest.raises(AIError) as exc:
        make().correct_sentence("hi")
    assert exc.value.kind is AIErrorKind.NETWORK


def test_key_not_in_error_messages(monkeypatch):
    def boom(*a, **k):
        raise urllib.error.HTTPError("u", 401, "x", {}, io.BytesIO(b"{}"))

    monkeypatch.setattr("urllib.request.urlopen", boom)
    with pytest.raises(AIError) as exc:
        make().correct_sentence("hi")
    assert "sk-test" not in exc.value.message


def test_image_payloads(monkeypatch):
    seen = {}

    def fake_post(self, url, headers, payload, timeout):
        seen["payload"] = payload
        return {"choices": [{"message": {"content": "ok"}}], "content": [{"type": "text", "text": "ok"}]}

    monkeypatch.setattr(AIService, "_post_json", fake_post)
    make().complete("sys", "look", image=(b"abc", "image/jpeg"))
    part = seen["payload"]["messages"][1]["content"][1]
    assert part["image_url"]["url"].startswith("data:image/jpeg;base64,")
    s = Settings(provider=PROVIDER_ANTHROPIC, base_url="https://api.anthropic.com", model="m")
    make(s).complete("sys", "look", image=(b"abc", "image/jpeg"))
    assert seen["payload"]["messages"][0]["content"][0]["source"]["media_type"] == "image/jpeg"
