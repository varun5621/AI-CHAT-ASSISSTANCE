import pytest

from app.services.ai_service import AIError, AIErrorKind
from app.services.message_analyzer import STANDARD_TONE, MessageAnalyzer, build_system_prompt, parse_analysis

GOOD = '''{"needs_reply": true, "author": "Sam", "incoming": "wyd tonight, ngl i'm bored",
"meaning": "He asks what you're doing.", "slang": [{"term": "ngl", "meaning": "not gonna lie"}],
"replies": [{"label": "Casual", "text": "nothing much, you?"}, {"label": "Playful", "text": "plotting world domination"},
{"label": "Friendly", "text": "free if you wanna hop on"}, {"label": "Extra", "text": "ignored"}]}'''


def test_parse_good():
    a = parse_analysis(GOOD)
    assert a.needs_reply and a.author == "Sam" and len(a.replies) == 3
    assert a.slang == (("ngl", "not gonna lie"),)


def test_parse_no_reply_needed_without_replies():
    a = parse_analysis('{"needs_reply": false, "meaning": "Your own message is last."}')
    assert not a.needs_reply and a.replies == ()


@pytest.mark.parametrize("bad", ["", "nope", '{"needs_reply": true, "replies": []}'])
def test_parse_bad(bad):
    with pytest.raises(AIError) as exc:
        parse_analysis(bad)
    assert exc.value.kind is AIErrorKind.INVALID_RESPONSE


def test_prompt_rules():
    p = build_system_prompt(STANDARD_TONE, "Varun")
    assert '"Varun"' in p and "untrusted" in p and "accent, nationality" in p
    assert "Gamer style" in build_system_prompt("Gamer style", "")


class FakeAI:
    def __init__(self): self.calls = []
    def complete(self, system, user, image=None):
        self.calls.append((user, image)); return GOOD


def test_text_and_image_paths():
    ai = FakeAI(); m = MessageAnalyzer(ai)
    assert m.analyze_message("wyd").replies
    assert ai.calls[0][1] is None
    m.analyze_image(b"jpegbytes")
    assert ai.calls[1][1] == (b"jpegbytes", "image/jpeg")
