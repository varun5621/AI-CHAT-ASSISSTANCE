import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtGui import QColor, QImage  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app.capture.region_capture import Region, signature  # noqa: E402
from app.services.live_watcher import LiveWatcher  # noqa: E402
from app.services.message_analyzer import Analysis, Reply  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def img(color):
    image = QImage(200, 100, QImage.Format_RGB32)
    image.fill(QColor(color))
    return image


def make_watcher(frames):
    it = iter(frames)
    watcher = LiveWatcher(None, lambda: "", lambda: "", grab=lambda r: next(it))
    submitted = []
    watcher._submit = lambda image: submitted.append(image)
    watcher.start(Region(0, 0, 200, 100), 3)
    watcher._timer.stop()
    return watcher, submitted


def test_signature_ignores_tiny_change_but_sees_big_one(qapp):
    a, b = img("#202020"), img("#202020")
    b.setPixelColor(5, 5, QColor("#222222"))
    assert signature(a) == signature(b)
    assert signature(a) != signature(img("#f0f0f0"))


def test_submits_only_after_screen_settles(qapp):
    w, sent = make_watcher([img("#202020")] * 2 + [img("#f0f0f0")] + [img("#f0f0f0")] + [img("#f0f0f0")])
    w._tick(); assert not sent          # baseline
    w._tick(); assert len(sent) == 1    # settled -> analyze the current chat once
    w._busy = False
    w._tick(); assert len(sent) == 1    # changed, still settling
    w._tick(); assert len(sent) == 2    # settled -> analyze again
    w._tick(); assert len(sent) == 2    # unchanged -> no extra AI call


def test_pause_stops_capturing(qapp):
    w, sent = make_watcher([img("#202020")] * 5)
    w.pause()
    w._tick(); w._tick()
    assert not sent and w.state == "paused"


def test_duplicate_incoming_is_not_shown_twice(qapp):
    w, _ = make_watcher([img("#202020")])
    shown = []
    w.analysis_ready.connect(shown.append)
    a = Analysis(True, "Sam", "wyd?", "m", (), (Reply("Casual", "nm"),))
    w._on_result(a); w._on_result(a)
    assert len(shown) == 1
    w._on_result(Analysis(False, "", "", "your msg is last", (), ()))
    assert len(shown) == 1
