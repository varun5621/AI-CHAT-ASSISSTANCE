import os

from app.storage.settings_manager import (
    ENV_KEY_NAME, SecretStore, Settings, SettingsManager, load_dotenv, provider_needs_no_key,
)


def test_settings_roundtrip(tmp_path):
    mgr = SettingsManager(tmp_path / "settings.json")
    mgr.settings.model = "my-model"
    mgr.save()
    assert SettingsManager(tmp_path / "settings.json").settings.model == "my-model"


def test_corrupt_settings_use_defaults(tmp_path):
    path = tmp_path / "settings.json"
    path.write_text("{not json", encoding="utf-8")
    assert SettingsManager(path).settings == Settings()


def test_api_key_never_in_settings_file(tmp_path, monkeypatch):
    monkeypatch.delenv(ENV_KEY_NAME, raising=False)
    store = SecretStore(tmp_path / "secrets.env")
    store.set_api_key("sk-test-1234567890")
    mgr = SettingsManager(tmp_path / "settings.json")
    mgr.save()
    assert "sk-test" not in (tmp_path / "settings.json").read_text()
    assert store.get_api_key() == "sk-test-1234567890"
    store.clear_api_key()
    assert store.get_api_key() is None


def test_dotenv_does_not_override_existing(tmp_path, monkeypatch):
    monkeypatch.setenv(ENV_KEY_NAME, "from-env")
    env = tmp_path / ".env"
    env.write_text(f"{ENV_KEY_NAME}=from-file\n", encoding="utf-8")
    load_dotenv(env)
    assert os.environ[ENV_KEY_NAME] == "from-env"


def test_local_provider_needs_no_key():
    assert provider_needs_no_key(Settings(base_url="http://localhost:11434/v1"))
    assert not provider_needs_no_key(Settings())
