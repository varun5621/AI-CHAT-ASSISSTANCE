import pytest

from app.services.ai_service import EditResult
from app.services.grammar_corrector import CorrectionAction, GrammarCorrector
from app.utils.validators import ValidationError


class FakeAI:
    def __init__(self):
        self.calls = []

    def correct_sentence(self, s):
        self.calls.append(("correct", s)); return EditResult(s, "c", "")

    def explain_grammar(self, s):
        self.calls.append(("explain", s)); return EditResult(s, "c", "")

    def improve_sentence(self, s, style):
        self.calls.append((style, s)); return EditResult(s, "c", "")


@pytest.mark.parametrize("action,expected", [
    (CorrectionAction.CORRECT, "correct"), (CorrectionAction.EXPLAIN, "explain"),
    (CorrectionAction.NATURAL, "natural"), (CorrectionAction.CASUAL, "casual"),
    (CorrectionAction.SHORTER, "shorter"), (CorrectionAction.VOCABULARY, "vocabulary"),
])
def test_dispatch(action, expected):
    ai = FakeAI()
    GrammarCorrector(ai).run(action, "  hello  ")
    assert ai.calls == [(expected, "hello")]


def test_empty_rejected():
    with pytest.raises(ValidationError):
        GrammarCorrector(FakeAI()).run(CorrectionAction.CORRECT, "   ")
