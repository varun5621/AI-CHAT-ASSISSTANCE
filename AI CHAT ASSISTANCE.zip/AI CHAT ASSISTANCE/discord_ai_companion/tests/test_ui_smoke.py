import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app.services.ai_service import AIService  # noqa: E402
from app.services.grammar_corrector import GrammarCorrector  # noqa: E402
from app.storage.settings_manager import SecretStore, SettingsManager  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402
from app.ui.theme import STYLESHEET  # noqa: E402


@pytest.fixture(scope="module")
def app():
    instance = QApplication.instance() or QApplication([])
    instance.setStyleSheet(STYLESHEET)
    return instance


def build(tmp_path, key):
    mgr = SettingsManager(tmp_path / "s.json")
    secrets = SecretStore(tmp_path / "secrets.env")
    ai = AIService(lambda: mgr.settings, lambda: key)
    return MainWindow(mgr, secrets, ai, GrammarCorrector(ai))


def test_launches_without_api_key(app, tmp_path):
    win = build(tmp_path, None)
    win.show()
    assert not win.banner.isHidden()
    assert all(not b.isEnabled() for b in win.correction_panel._buttons.values())
    win.close()


def test_buttons_enabled_with_key(app, tmp_path):
    win = build(tmp_path, "sk-test-123456789")
    win.show()
    assert win.banner.isHidden()
    assert all(b.isEnabled() for b in win.correction_panel._buttons.values())
    win.close()


def test_notifications_show_the_message_text(app, tmp_path):
    win = build(tmp_path, "sk-test-123456789")
    win.show()
    win.reply_panel.notify.emit("error", "The API key was rejected. Check it in Settings.")
    assert win.toast.text() == "The API key was rejected. Check it in Settings."
    assert win.toast.property("kind") == "error"
    win.close()
